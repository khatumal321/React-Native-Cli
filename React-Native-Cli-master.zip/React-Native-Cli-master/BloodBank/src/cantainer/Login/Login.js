import React, { Component } from 'react';
import { View, Image } from 'react-native';
import Form from './../../component/form/form'
import Button from './../../component/Button/Button'
export default class FloatingLabelExample extends Component {
  render() {
    return (
      <View>
        <Image
          style={{ width: 120, height: 80, justifyContent: 'center', alignItems: 'center', flex: 1}}
          source={require('./../../component/Logo/Blood-bank.jpg')}
        />
        <Form style={{justifyContent: 'center', alignItems: 'center'}}/>
        {/* <Button /> */}
      </View>
    );
  }
}