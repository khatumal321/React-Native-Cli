import React, { Component } from 'react';
import { Container, Header, Content, Form, Item, Input, Label } from 'native-base';
export default class FloatingLabelExample extends Component {
  render() {
    return (
    
          <Form style={{justifyContent: 'center', alignContent: 'center', flex: 1, backgroundColor: 'none'}}>
            <Item floatingLabel >
              <Label style={{fontSize: 25}}>Username</Label>
              <Input />
            </Item>
            <Item floatingLabel last>
              <Label  style={{fontSize: 25}}>Password</Label>
              <Input />
            </Item>
          </Form>
      
    );
  }
}